#include <ncurses.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stdio.h>

int row,col;
int boardrow=4, boardcol=5, newtiles=1;
int boardmax = 8, boardmin=4;
int newtilemax=4, newtilemin=1;
int setupstate;
int regame=0;
int score = 0;
int highscore=1000;
int num[8][8]; int pastnum[8][8];

WINDOW *menu; WINDOW *setup; WINDOW *scoreboard; WINDOW *saveload;
WINDOW *board[8][8]; WINDOW *bestscore, *currscore;

FILE *sl[10];
FILE *sc;

struct _score{
	int point;
	char name[11];
	char time[40];
};
struct _score scores[10];

struct _savedata{
	bool isdata; 
	int pastgrid[8][8];
	int currgrid[8][8];
	int point;
	int gridrow;
	int gridcol;
	int randtile;
	char time[30];
};
struct _savedata savedata[10];

int savegame();
int loadgame();
int printsaveload();
int saveloadstate=0;
WINDOW *saveload;

int drawsubmenu();
int drawmenu();
int updatescreen();
int printsetup();
int movewin();
int drawboard();

int intlen();
int emptytiles();
int gamestart();
int game();
int initboard();
int isdir();
int moveboard();
int unchangedboard();
int nomoremoves();
int savepast();
int makenewtile();
int option();
int sortscore();
int swapscore();
int savescore();
int printscore();
int ishighscore();

int updatescreen(WINDOW *screen){
	touchwin(screen);
	touchwin(stdscr);
	refresh();
	return 0;
}

int drawmenu(WINDOW *menu,int state){
	werase(menu);
	wbkgd(menu,COLOR_PAIR(2));
	mvwprintw(menu,1,18,"MENU");
	mvwprintw(menu,2,5,"START");
	mvwprintw(menu,3,5,"LOAD");
	mvwprintw(menu,4,5,"SCORE");
	mvwprintw(menu,5,5,"SETUP");
	mvwprintw(menu,6,5,"EXIT");
	mvwprintw(menu,2+state,4,">");
	updatescreen(menu);
	return 0;
}

int drawsubmenu(WINDOW *stop, int state){
	werase(stop);
	wbkgd(stop,COLOR_PAIR(4));
	mvwprintw(stop,1,5,"RESUME");
	mvwprintw(stop,2,5,"NEW GAME");
	mvwprintw(stop,3,5,"SAVE");
	mvwprintw(stop,4,5,"EXIT");
	mvwprintw(stop,1+state,4,">");
	wrefresh(stop);
}

int initboard(){
	int i,j;
	for(i=0;i<8;i++){
		for(j=0;j<8;j++){
			num[i][j] = 0;
			pastnum[i][j] = 0;
		}
	}
	score = 0;
	sortscore();
	highscore = scores[0].point;
	makenewtile(2);
	return 0;
}

int intlen(int a){
	int len = 0;
	while(a!=0){
		a /= 10;
		len++;
	}
	return len;
}

int drawboard(){
	int i,j;
	for(i=0;i<8;i++){
		for(j=0;j<8;j++){
			werase(board[i][j]);
			wbkgd(board[i][j],COLOR_PAIR(1));
		}
	}
	for(i=0;i<boardrow;i++){
		for(j=0;j<boardcol;j++){
			if(num[i][j] == 0){
				wbkgd(board[i][j],COLOR_PAIR(8));
			}
			else if(num[i][j]<10){
				wbkgd(board[i][j],COLOR_PAIR(3));
			}
			else if(num[i][j]<100){
				wbkgd(board[i][j],COLOR_PAIR(5));
			}
			else if(num[i][j]<1000){
				wbkgd(board[i][j],COLOR_PAIR(6));
			}
			else{
				wbkgd(board[i][j],COLOR_PAIR(7));
			}
			keypad(board[i][j],TRUE);
			if(num[i][j] != 0){
				mvwprintw(board[i][j],2,5-intlen(num[i][j])/2,"%d",num[i][j]);
			}
		updatescreen(board[i][j]);
		}
	}
	werase(bestscore); werase(currscore);
	wbkgd(bestscore,COLOR_PAIR(4));
	wbkgd(currscore,COLOR_PAIR(4));
	if(score>highscore){
		highscore = score;
	}
	mvwprintw(bestscore,1,2,"Best: %d",highscore);
	mvwprintw(currscore,1,2,"Score: %d",score);
	touchwin(stdscr); refresh();
	return 0;
}

int ishighscore(){
	sortscore();
	if(score>scores[9].point){
		return 1;
	}
	return 0;
}

int swapscore(int i, int j){
	int temp; char str1[11];char str2[30];
	temp = scores[i].point;
	scores[i].point = scores[j].point;
	scores[j].point = temp;
	strcpy(str1,scores[i].name);
	strcpy(scores[i].name,scores[j].name);
	strcpy(scores[j].name,str1);
	strcpy(str2,scores[i].time);
	strcpy(scores[i].time,scores[j].time);
	strcpy(scores[j].time,str2);
	return 0;
}

int sortscore(){
	int i,j;
	for(i=0;i<10;i++){
		for(j=0;j<9-i;j++){
			if(scores[j].point<scores[j+1].point){
				swapscore(j,j+1);
			}
		}
	}
}

int emptytiles(){
	int i,j; int ret = 0;
	for(i=0;i<boardrow;i++){
		for(j=0;j<boardcol;j++){
			if(num[i][j]==0){
				ret++;
			}
		}
	}
	return ret;
}

int nomoremoves(){
	int i,j;
	if(emptytiles()){
		return 0;
	}
	for(i=0;i<boardrow;i++){
		for(j=0;j<boardcol-1;j++){
			if(num[i][j] == num[i][j+1]){
				return 0;
			}
		}
	}
	for(j=0;j<boardcol;j++){
		for(i=0;i<boardrow-1;i++){
			if(num[i][j] == num[i+1][j]){
				return 0;
			}
		}
	}
	return 1;
}

int drawtitle(){
	mvwprintw(stdscr,0,row/2 -36,"{__{___     {__{___ {______      {__       {__      {_       {__      {__\n");
	mvwprintw(stdscr,1,row/2 -36,"{__{_ {__   {__     {__          {_ {__   {___     {_ __      {__   {__\n");
	mvwprintw(stdscr,2,row/2 -36,"{__{__ {__  {__     {__          {__ {__ { {__    {_  {__      {__ {__   \n");
	mvwprintw(stdscr,3,row/2 -36,"{__{__  {__ {__     {__          {__  {__  {__   {__   {__       {__     \n");
	mvwprintw(stdscr,4,row/2 -36,"{__{__   {_ {__     {__          {__   {_  {__  {______ {__    {__ {__   \n");
	mvwprintw(stdscr,5,row/2 -36,"{__{__    {_ __     {__          {__       {__ {__       {__  {__   {__  \n");
	mvwprintw(stdscr,6,row/2 -36,"{__{__      {__     {__          {__       {__{__         {__{__      {__\n");
 	mvwprintw(stdscr,7,row/2 -36,"                          {_____       ");
	refresh();
}

int gamestart(){
	int key; int menustate=0;
	drawtitle(); bool quit = FALSE, loaded;
	drawmenu(menu,menustate);
	initboard();
	while(1){
		quit = FALSE;
		key = getch();
		if(key == KEY_UP || key == KEY_DOWN){
			if(menustate<4 && key == KEY_DOWN){
				menustate++;
			}
			if(key == KEY_UP && menustate>0){
				menustate--;
			}
			drawmenu(menu,menustate);
			updatescreen(menu);
		}
		else if(key == '\n'){
			wbkgd(menu,COLOR_PAIR(1));
			werase(menu);
			switch(menustate){
				case 0:
					game(row,col);
					drawmenu(menu,menustate);
					drawtitle();
					break;
				case 1:
					//load
					loaded = loadgame();
					if(loaded){
						erase();
						drawtitle();
						game(row,col);
					}
					erase();
					drawmenu(menu,menustate);
					drawtitle();
					break;
				case 2:
					//score
					printscore();
					erase();
					drawmenu(menu,menustate);
					drawtitle();
					break;
				case 3:
					//setup
					option();
					drawmenu(menu,menustate);
					drawtitle();
					break;
				case 4:
					quit = TRUE;
					break;
			}
		}
		if(quit){
			break;
		}
		refresh();
	}
	return 0;
}

int isdir(int input){
	if(input == KEY_UP){
		return 1;
	}
	if(input == KEY_RIGHT){
		return 2;
	}
	if(input == KEY_DOWN){
		return 3;
	}
	if(input == KEY_LEFT){
		return 4;
	}
	return 0;
}

int savepast(){
	int i,j;
	for(i=0;i<boardrow;i++){
		for(j=0;j<boardcol;j++){
			pastnum[i][j] = num[i][j];
		}
	}
	return 0;
}

int unchangedboard(){
	int i,j;
	for(i=0;i<boardrow;i++){
		for(j=0;j<boardcol;j++){
			if(num[i][j] !=pastnum[i][j]){
				return 1;
			}
		}
	}
	return 0;
}

int moveboard(int input){
	int i,j; int exit;
	int count, newnum;
	savepast();
	switch(isdir(input)){
		case 1:
			for(j=0;j<boardcol;j++){
				for(i=1;i<boardrow;i++){
					if(num[i][j] == 0){
						continue;
					}
					else if(num[i-1][j] == 0){
						num[i-1][j] = num[i][j];
						num[i][j] = 0;
						i = 1;
					}
				}
				for(i=0;i<boardrow-1;i++){
					if(num[i][j] == num[i+1][j] && num[i][j] != 0){
						num[i][j] *= 2;
						score += num[i][j];
						num[i+1][j] = 0;
					}
				}
				for(i=1;i<boardrow;i++){
					if(num[i][j] == 0){
						continue;
					}
					else if(num[i-1][j] == 0){
						num[i-1][j] = num[i][j];
						num[i][j] = 0;
						i = 1;
					}
				}
			}
			break;
		case 3:
			for(j=0;j<boardcol;j++){
				for(i=boardrow-2;i>=0;i--){
					if(num[i][j] == 0){
						continue;
					}
					else if(num[i+1][j] == 0){
						num[i+1][j] = num[i][j];
						num[i][j] = 0;
						i = boardcol-2;
					}
				}
				for(i=boardrow-1;i>0;i--){
					if(num[i][j] == num[i-1][j] && num[i][j] != 0){
						num[i][j] *= 2;
						score += num[i][j];
						num[i-1][j] = 0;
					}
				}
				for(i=boardrow-2;i>=0;i--){
					if(num[i][j] == 0){
						continue;
					}
					else if(num[i+1][j] == 0){
						num[i+1][j] = num[i][j];
						num[i][j] = 0;
						i = boardcol-2;
					}
				}
			}
			break;
		case 2:
			for(i=0;i<boardrow;i++){
				for(j=boardcol-2;j>=0;j--){
					if(num[i][j] == 0){
						continue;
					}
					else if(num[i][j+1] == 0){
						num[i][j+1] = num[i][j];
						num[i][j] = 0;
						j = boardcol-2;
					}
				}
				for(j=boardcol-1;j>0;j--){
					if(num[i][j] == num[i][j-1] && num[i][j] !=0){
						num[i][j]*=2;
						score += num[i][j];
						num[i][j-1] = 0;
					}
				}
				for(j=boardcol-2;j>=0;j--){
					if(num[i][j] == 0){
						continue;
					}
					else if(num[i][j+1] == 0){
						num[i][j+1] = num[i][j];
						num[i][j] = 0;
						j = boardcol-2;
					}
				}
			}
			break;
		case 4:
			for(i=0;i<boardrow;i++){
				for(j=1;j<boardcol;j++){
					if(num[i][j] == 0){
						continue;
					}
					else if(num[i][j-1] == 0){
						num[i][j-1] = num[i][j];
						num[i][j] = 0;
						j = 1;
					}
				}
				for(j=0;j<boardcol-1;j++){
					if(num[i][j] == num[i][j+1] && num[i][j] != 0){
						num[i][j] *=2;
						score += num[i][j];
						num[i][j+1] = 0;
					}
				}
				for(j=1;j<boardcol;j++){
					if(num[i][j] == 0){
						continue;
					}
					else if(num[i][j-1] == 0){
						num[i][j-1] = num[i][j];
						num[i][j] = 0;
						j = 1;
					}
				}
			}
			break;
	}

	if(unchangedboard() == 1 && emptytiles() != 0){
		if(emptytiles()>=newtiles){
			makenewtile(newtiles);
		}else{
			makenewtile(emptytiles());
		}
		drawboard();
	}
	return 0;
	
}

int makenewtile(int n){
	int empty; int i,j; int newtile; int count;
	for(i=1;i<=n;i++){
		empty = emptytiles();
		newtile = rand() % empty;
		count= 0;
		for(j=0;j<boardrow*boardcol;j++){
			if(num[j/boardcol][j%boardcol] == 0){
				if(count == newtile){
					num[j/boardcol][j%boardcol] = 2 + (rand()%10 == 0)*2;
					break;
				}
				count++;
			}
		}
	}
	return 0;
}

int printsetup(){
	werase(setup);
	setup = subwin(stdscr,7,30,col/2 - 2, row/2 - 15);
	wbkgd(setup,COLOR_PAIR(4));
	mvwprintw(setup,0,13,"SETUP");
	mvwprintw(setup,2,2,"NUMBER OF ROWS: %d",boardrow);
	mvwprintw(setup,3,2,"NUMBER OF COLS: %d",boardcol);
	mvwprintw(setup,4,2,"NUMBER OF RANDOM TILE: %d",newtiles);
	mvwprintw(setup,5,2,"OK");
	mvwprintw(setup,(2+setupstate),1,">");
	touchwin(stdscr);
	refresh();
	return 0;
}

int printscore(){
	int i;
	sortscore();
	werase(scoreboard);
	scoreboard = subwin(stdscr,14,70,col/2-7,row/2-35);
	wbkgd(scoreboard,COLOR_PAIR(4));
	mvwprintw(scoreboard,1,32,"SCORE");
	for(i=0;i<10;i++){
		if(scores[i].point == 0){
			mvwprintw(scoreboard,2+i,2,"----------");
		}
		else{
			mvwprintw(scoreboard,2+i,2,"%2d. Name: %10s  Score: %8d @ %s",i+1,scores[i].name,scores[i].point,scores[i].time);
		}
	}
	mvwprintw(scoreboard,12,34,">OK");
	touchwin(stdscr);
	refresh();
	while(1){
		if(getch() == '\n'){
			break;
		}
	}
	return 0;
}

int option(){
	int input; int *nums[3][3];
	nums[0][0] = &boardrow; nums[0][1] = &boardmin; nums[0][2] = &boardmax;
	nums[1][0] = &boardcol;nums[1][1] = &boardmin; nums[1][2] = &boardmax; 
	nums[2][0] = &newtiles; nums[2][1] = &newtilemin; nums[2][2] = &newtilemax;
	while(1){
		printsetup();
		input = getch();
		if(input == KEY_DOWN){
			if(setupstate<3){
				setupstate++;
			}
		}
		if(input == KEY_UP){
			if(setupstate>0){
				setupstate--;
			}
		}
		if(input == KEY_RIGHT && setupstate!=3){
			if(*nums[setupstate][0] <*nums[setupstate][2]){
				*nums[setupstate][0]+=1;
			}
		}
		if(input == KEY_LEFT && setupstate!=3){
			if(*nums[setupstate][0] > *nums[setupstate][1]){
				*nums[setupstate][0]-=1;
			}
		}
		if(input == '\n'){
			if(setupstate == 3){
				break;
			}
		}
		// if input is number -> if number is in between -> change to number
		if(input >= '1' && input <= '8' && setupstate!=3){
			input -= '0';
			if(input>=*nums[setupstate][1] && input <= *nums[setupstate][2]){
				*nums[setupstate][0] = input;
			}
		}
	}
	return 0;
}

int movewin(){
	int i,j;
	for(i=0;i<8;i++){
		for(j=0;j<8;j++){
			mvderwin(board[i][j],col/2 +6*i+3 - 3*boardrow, row/2 - (6*boardcol - 12*j));
		}
	}
}

int loadgame(){
	saveloadstate=0;
	int i,j,k; char filename[15];
	for(i=0;i<10;i++){
		sprintf(filename,"save%d.intmax",i);
		sl[i] = fopen(filename,"r");	
		if(sl[i] == NULL){
			savedata[i].isdata = FALSE;
		}
		else{
			savedata[i].isdata = TRUE;
			fscanf(sl[i],"%d %d %d %d\n",&savedata[i].point,&savedata[i].gridrow,&savedata[i].gridcol,&savedata[i].randtile);
			for(j=0;j<savedata[i].gridrow;j++){
				for(k=0;k<savedata[i].gridcol;k++){
					fscanf(sl[i],"%d %d ",&savedata[i].pastgrid[j][k],&savedata[i].currgrid[j][k]);
				}
				fscanf(sl[i],"\n");
			}
			fgets(savedata[i].time,100,sl[i]);
		fclose(sl[i]);
		}
	}

	while(1){
		printsaveload();
		i = getch();
		if(saveloadstate > 0 && i == KEY_UP){
			saveloadstate--;
		}
		else if(saveloadstate<10 && i == KEY_DOWN){
			saveloadstate++;
		}
		else if(i == '\n'){
			if(saveloadstate == 10){
				return 0;
			}
			else if(savedata[saveloadstate].isdata){ 
				score = savedata[saveloadstate].point;
				boardrow = savedata[saveloadstate].gridrow;
				boardcol = savedata[saveloadstate].gridcol;
				newtiles = savedata[saveloadstate].randtile;
				for(j=0;j<boardrow;j++){
					for(k=0;k<boardcol;k++){
						num[j][k] = savedata[saveloadstate].currgrid[j][k];
						pastnum[j][k] = savedata[saveloadstate].pastgrid[j][k];
					}
				}
				return 1;
			}
			
		}
	}
	return 1;
}

int savegame(){
	int i,j,k; char filename[15]; time_t currtime;
	saveloadstate=0;
	while(1){
		printsaveload();
		i = getch();
		if(saveloadstate > 0 && i == KEY_UP){
			saveloadstate--;
		}
		else if(saveloadstate<10 && i == KEY_DOWN){
			saveloadstate++;
		}
		else if(saveloadstate == 10 && i == '\n'){
			return 0;
		}
		else if(i == '\n'){
			sprintf(filename,"save%d.intmax",saveloadstate);
			sl[saveloadstate] = fopen(filename,"w");	
			fprintf(sl[saveloadstate],"%d %d %d %d\n",score,boardrow,boardcol,newtiles);
			for(j=0;j<boardrow;j++){
				for(k=0;k<boardcol;k++){
					fprintf(sl[saveloadstate],"%d %d ",pastnum[j][k],num[j][k]);
					savedata[saveloadstate].currgrid[j][k] = num[j][k];
					savedata[saveloadstate].pastgrid[j][k] = pastnum[j][k];
				}
				fprintf(sl[saveloadstate],"\n");
			}
			savedata[saveloadstate].isdata = TRUE;
			savedata[saveloadstate].point = score;
			savedata[saveloadstate].gridrow = boardrow;
			savedata[saveloadstate].gridcol = boardcol;
			savedata[saveloadstate].randtile = newtiles;
			time(&currtime);
			strcpy(savedata[saveloadstate].time,ctime(&currtime));
			fprintf(sl[saveloadstate],"%s",savedata[saveloadstate].time);
			fclose(sl[saveloadstate]);
		}
	}
		return 0;
}

int printsaveload(){
	int i;
	werase(saveload);
	saveload = subwin(stdscr, 13,72, col/2-4,row/2-36);
	wbkgd(saveload,COLOR_PAIR(4));
	for(i=0;i<10;i++){
		if(savedata[i].isdata){
			mvwprintw(saveload,1+i,2,"Grid : %d x %d / Random: %d / %8d Points @ %s",savedata[i].gridrow,savedata[i].gridcol,savedata[i].randtile,savedata[i].point,savedata[i].time);
		}
		else{
			mvwprintw(saveload,1+i,2,"(Empty Slot)");
		}
	}
	mvwprintw(saveload,1+saveloadstate,1,">");
	mvwprintw(saveload,11,2,"EXIT");
	wrefresh(saveload);
}

int game(int row, int col){
	WINDOW *gameover;
	WINDOW *stop;
	char name[11];
	int input; int key; int namecount=0;
	int i,j; int a,b; int endmenu;
	int random, submenustate=0;
	time_t currtime;
	movewin();
	drawboard();
	while(1){
		input = getch();
		if(input == 'm'){
			touchwin(stdscr);
			refresh();
			stop = newwin(6,30,col/2 - 3, row/2-15 );
			submenustate=0;
			drawsubmenu(stop,submenustate);
			endmenu = 0;
			while(1){
				key = getch();
				if(key == KEY_UP || key == KEY_DOWN){
					if(submenustate<3 && key == KEY_DOWN){
						submenustate++;
					}
					if(key == KEY_UP && submenustate>0){
						submenustate--;
					}
				}
				if(key == '\n'){
					endmenu=1;
					if(submenustate == 0){//resume
					}
					if(submenustate == 1){//New Game
						initboard();
						drawboard();
					}
					if(submenustate == 2){//Save
						savegame();
						drawboard();
					}
					if(submenustate == 3){//Exit
						regame =1;
						initboard();
					}
				}
				drawsubmenu(stop,submenustate);
				wrefresh(stop);
				if(endmenu == 1){
					erase();
					delwin(stop);
					if(submenustate!=3){
						drawboard();
					}
					else{
						initboard();
					}
					drawtitle();
					break;
				}
			}

		}
		else if(isdir(input)){
			moveboard(input);
		}
		if(nomoremoves()){
			stop = newwin(5,70,col/2, row/2 - 36);
			wbkgd(stop,COLOR_PAIR(4));
			namecount=0;
			if(ishighscore(score)){
				mvwprintw(stop,2,9,"GAME OVER!! Enter your name : ");
				curs_set(1);
				wrefresh(stop);
				while(1){
					input = getch();
					if(namecount<10 && namecount >= 0 && ((input >= 'a' && input <= 'z') || (input >= 'A' && input <= 'Z'))){
						name[namecount] = input;
						name[namecount+1] = 0;		
						mvwprintw(stop,2,9,"GAME OVER!! Enter your name : %s",name);
						wrefresh(stop);
						namecount+=1;
					}
					else if(input == KEY_BACKSPACE && namecount>0){
						namecount-=1;
						name[namecount] = 0;
						werase(stop);
						mvwprintw(stop,2,9,"GAME OVER!! Enter your name : %s",name);
						wrefresh(stop);
					}
					else if(input == '\n' && namecount>0){
						scores[9].point = score;
						strcpy(scores[9].name,name);
						time(&currtime);
						strcpy(scores[9].time,ctime(&currtime));
						curs_set(0);
						sortscore();
						regame = 1;
						erase();
						delwin(stop);
						initboard();
						savescore();
						break;
					}
				}
			}
			else{
				mvwprintw(stop,2,9,"GAME OVER!! Press Enter to go back to the main menu.");
				wrefresh(stop);
				refresh();
				while(1){
					input = getch();
					if(input == '\n'){
						erase();
						delwin(stop);
						regame = 1;
						initboard();
						break;
					}
				}
			}
		}
		if(regame == 1){
			regame = 0;
			break;
		}
	}
	return 0;
}

int main(){
	int i,j; char strin[100];
	srand(time(NULL));
	initscr();
	noecho();
	keypad(stdscr,TRUE);
	keypad(menu,TRUE);
	curs_set(0);
	start_color();

	//score init
	sc = fopen("score.intmax","r");	
	if(sc == NULL){
		sc = fopen("score.intmax","w");
	}
	for(i=0;i<10;i++){
		scores[i].point = 0;
	}
	i=0;
	while(fgets(strin,100,sc) != NULL){
		if(strin[0]!='\n'){
		sscanf(strin,"%d %s %[^\n]s",&scores[i].point,scores[i].name,scores[i].time);
		i++;
		}
	}
	sortscore();
	fclose(sc);
	highscore = scores[0].point;
	init_pair(1,COLOR_YELLOW,COLOR_BLUE);
	init_pair(2,COLOR_BLACK,COLOR_YELLOW);
	init_pair(3,COLOR_YELLOW,COLOR_MAGENTA);
	init_pair(5,COLOR_RED,COLOR_GREEN);
	init_pair(6,COLOR_BLACK,COLOR_WHITE);
	init_pair(7,COLOR_WHITE,COLOR_BLACK);
	init_pair(8,COLOR_MAGENTA,COLOR_YELLOW);
	init_pair(4,COLOR_RED,COLOR_CYAN);
	bkgd(COLOR_PAIR(1));
	getmaxyx(stdscr,col,row);
	menu = subwin(stdscr,8,40,col/2-3,row/2-20);
	for(i=0;i<8;i++){
		for(j=0;j<8;j++){
			board[i][j] = subwin(stdscr,5,10,col/2 +6*i+3 - 3*8, row/2 - (6*8 - 12*j));
		}
	}
	bestscore = subwin(stdscr,3,20,10,40);
	currscore = subwin(stdscr,3,20,10,row-60);
	movewin();
	gamestart();
	endwin();
	return 0;	
}

int savescore(){
	int i;
	sc= fopen("score.intmax","w");
	sortscore();
	for(i=0;i<10;i++){
		if(scores[i].point!=0){
			fprintf(sc,"%d %s %s\n",scores[i].point,scores[i].name,scores[i].time);
		}
	}
	fclose(sc);
	return 0;
}
